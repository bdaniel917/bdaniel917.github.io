#define _POSIX_C_SOURCE 200809L
#include "../dsp.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <assert.h>

static void selftest(void){
    int clip;double q,d;uint64_t count=0;
    assert(adc_step(0,8,&clip,&q,&d)==0&&!clip);
    assert(adc_step(1,8,&clip,&q,&d)==127./128&&clip&&d==-1./128);
    assert(adc_step(-1,8,&clip,&q,&d)==-1&&!clip);
    assert(adc_step(.5/128,8,&clip,&q,&d)==1./128);
    assert(adc_step(-.5/128,8,&clip,&q,&d)==-1./128);
    assert(adc_step(127.49/128,8,&clip,&q,&d)==127./128&&!clip);
    assert(adc_step(127.5/128,8,&clip,&q,&d)==127./128&&clip);
    assert(shift_round(5,1,0)==3&&shift_round(-5,1,0)==-3);
    assert(shift_round(5,1,1)==2&&shift_round(-5,1,1)==-2);
    assert(limit_int(128,8,0,&count)==127&&count==1);
    assert(limit_int(128,8,1,&count)==-128&&count==2);
    assert(limit_int(-129,8,1,&count)==127&&count==3);
    puts("ADC transitions, ties, rounding, saturation, and wrap assertions passed");
}
static double seconds(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static void benchmark(void){
    enum{CHANNELS=8,BLOCK=64,REPS=4000};double input[BLOCK],out[BLOCK],elapsed[5],check=0;
    for(int i=0;i<BLOCK;i++)input[i]=.2*sin(2*DSP_PI*93*i/2000.);
    for(int trial=0;trial<5;trial++){
        FixedFilter f[CHANNELS];for(int c=0;c<CHANNELS;c++)f[c]=fixed_init(notch_coeff(2000,60,25),16,15,28,62,0,0,0);
        double start=seconds();
        for(int j=0;j<REPS;j++)for(int c=0;c<CHANNELS;c++){fixed_block(&f[c],input,out,BLOCK);check+=out[j%BLOCK];}
        elapsed[trial]=seconds()-start;
    }
    puts("trial,seconds,channel_samples_per_second,channels,block_samples,state_bytes_per_channel,checksum");
    for(int t=0;t<5;t++)printf("%d,%.9g,%.9g,%d,%d,%zu,%.17g\n",t,elapsed[t],(double)CHANNELS*BLOCK*REPS/elapsed[t],CHANNELS,BLOCK,sizeof(FixedFilter),check);
}
int main(int argc,char **argv){
    if(argc==2&&!strcmp(argv[1],"selftest")){selftest();return 0;}
    if(argc==2&&!strcmp(argv[1],"benchmark")){benchmark();return 0;}
    if(argc!=13){fprintf(stderr,"probe INPUT OUTPUT fs hz Q bits frac coeff_frac acc_bits truncate wrap realization:block\n");return 2;}
    FILE *in=fopen(argv[1],"r"),*out=fopen(argv[2],"w");if(!in||!out)return 2;
    double fs=atof(argv[3]),hz=atof(argv[4]),q=atof(argv[5]);int realization,block;
    if(sscanf(argv[12],"%d:%d",&realization,&block)!=2||block<1||block>65536)return 2;
    Coeff c=notch_coeff(fs,hz,q);FloatFilter ff={.c=c,.realization=realization};
    FixedFilter f=fixed_init(c,atoi(argv[6]),atoi(argv[7]),atoi(argv[8]),atoi(argv[9]),atoi(argv[10]),atoi(argv[11]),realization);
    double *x=calloc((size_t)block,sizeof(double)),*yf=calloc((size_t)block,sizeof(double)),*yq=calloc((size_t)block,sizeof(double));
    if(!x||!yf||!yq)return 2;
    fprintf(out,"float,fixed\n");
    while(1){size_t n=0;while(n<(size_t)block&&fscanf(in,"%lf",&x[n])==1)n++;if(!n)break;
        float_block(&ff,x,yf,n);fixed_block(&f,x,yq,n);
        for(size_t i=0;i<n;i++)fprintf(out,"%.17g,%.17g\n",yf[i],yq[i]);
    }
    fprintf(stderr,"input=%llu state=%llu accumulator=%llu\n",(unsigned long long)f.input_clips,(unsigned long long)f.state_clips,(unsigned long long)f.acc_clips);
    free(x);free(yf);free(yq);fclose(in);return fclose(out)?1:0;
}
